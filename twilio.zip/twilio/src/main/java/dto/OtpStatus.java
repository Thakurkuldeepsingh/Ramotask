package com.javatechie.twilio.dto;

public enum OtpStatus {

    DELIVERED,FAILED
}
