package com.javatechie.twilio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwilioOtpExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}